Altar press kit
prayaltar.com/press

Logos
- altar-icon-1024.png        App icon (dark), 1024 x 1024
- altar-icon-light-1024.png  App icon (light), 1024 x 1024
- altar-icon.svg             App icon, vector
- altar-lockup-dark.png      Mark and wordmark for dark backgrounds, 1800 x 600
- altar-lockup-light.png     Mark and wordmark for light backgrounds, 1800 x 600

Screenshots
Real captures of Altar 1.0 on iPhone, 1320 x 2868.

Please keep the flame warm on every background, and don't recolour,
stretch or add effects to the mark.

Questions: hello@prayaltar.com
Altar is made by ELAQ Limited.
